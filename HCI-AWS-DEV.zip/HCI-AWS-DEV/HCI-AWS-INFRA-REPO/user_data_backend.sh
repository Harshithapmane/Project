#!/bin/bash
echo ECS_CLUSTER=HCI-AWS-DEV-ecs-cluster-Backend >> /etc/ecs/ecs.config