#!/bin/bash
echo ECS_CLUSTER=HCI-AWS-DEV-ecs-cluster-frontend >> /etc/ecs/ecs.config