#!/bin/bash
echo ECS_CLUSTER=HCI-AWS-TEST-ecs-cluster-Backend >> /etc/ecs/ecs.config