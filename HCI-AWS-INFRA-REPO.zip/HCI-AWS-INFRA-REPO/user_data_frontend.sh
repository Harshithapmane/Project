#!/bin/bash
echo ECS_CLUSTER=HCI-AWS-TEST-ecs-cluster-frontend >> /etc/ecs/ecs.config